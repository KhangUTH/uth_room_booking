# Tổ chức tính năng

Mỗi tính năng có `models/` (dữ liệu), `data/` (repository, dữ liệu mẫu), `controllers/` (trạng thái/nghiệp vụ), `presentation/` (trang), `widgets/` (UI riêng).

`auth`, `profile`, `splash`, `room`, `equipment` có mã giao diện hiện tại. `booking`, `incident_report`, `technician` mới có khung chờ triển khai. Không thêm trang giả để biểu thị chức năng đã hoàn thành.

App chỉ hỗ trợ Sinh viên, Giảng viên, Nhân viên kỹ thuật. Vai trò thật phải lấy từ backend đã xác thực. Xem `docs/PROJECT_AUDIT.md` để biết phạm vi còn thiếu.
