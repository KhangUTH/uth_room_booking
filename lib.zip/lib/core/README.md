# Hạ tầng dùng chung

- `config/`: cấu hình môi trường; không lưu khóa quản trị hoặc mật khẩu.
- `network/`: khởi tạo client và kết nối backend khi tích hợp Supabase.
- `errors/`: chuẩn hóa lỗi kết nối, xác thực, dữ liệu.
- `utils/`: validation, định dạng ngày giờ và tiện ích dùng chung.

Hiện là khung thư mục. Repository nghiệp vụ đặt trong `features/<feature>/data/`.
